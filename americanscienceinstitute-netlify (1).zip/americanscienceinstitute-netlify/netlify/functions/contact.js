'use strict';
/* Contact, research proposal and partnership forms → email via SMTP. Mirrors api/contact.php. */
const C = require('../lib/common.js');
const D = C.DATA;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return C.json(405, { ok: false, message: 'Method not allowed.' });
  const b = C.parseBody(event), asJson = C.wantsJson(event);
  const respond = (ok, message, errors, status) => asJson ? C.json(status || 200, { ok, message, errors: errors || {} })
    : C.htmlPage(status || 200, ok ? 'Thank you, we’ve received your message' : 'We couldn’t send your message', message, errors, ok ? '/' : '/contact-us/');
  const type = ['contact', 'proposal', 'partnership'].includes(b.form_type) ? b.form_type : 'contact';
  const spam = C.spamCheck(b);
  if (spam === 'bot') return respond(true, 'Thank you. Your message has been received.');
  if (spam) return respond(false, spam, {}, 400);
  if (!(await C.verifyRecaptcha(b.recaptcha_token, type, C.header(event, 'x-nf-client-connection-ip')))) {
    return respond(false, 'We could not verify that this request came from a person. Please refresh the page and try again, or email us directly.', {}, 400);
  }
  const name = C.cleanLine(b.name, 120), email = C.cleanLine(b.email, 160), errors = {};
  if (!name) errors.name = 'Enter your full name.';
  if (!C.EMAIL.test(email)) errors.email = 'Enter an email address, like name@example.com.';
  const rows = { Name: name, Email: email };
  let subjectLine = '', kind = 'website inquiry', confirm = {};
  if (type === 'proposal') {
    const field = C.cleanLine(b.field, 120);
    if (!Object.values(D.fields).includes(field)) errors.field = 'Choose a research field.';
    const q = C.cleanText(b.question, 4000);
    if (q.length < 5) errors.question = 'Describe the research you would like to advance.';
    const support = D.support_types.includes(b.support) ? b.support : 'Not sure yet';
    Object.assign(rows, { 'Research field': field, 'Research question': q, 'Type of support': support, 'Intended contribution': C.cleanLine(b.amount, 80) || 'Not specified' });
    subjectLine = 'Research proposal: ' + field; kind = 'research proposal'; confirm = { 'Research field': field, 'Type of support': support };
  } else {
    const org = C.cleanLine(b.organization, 160), phone = C.cleanLine(b.phone, 40);
    if (phone && !/^[0-9+().\-\s]{7,40}$/.test(phone)) errors.phone = 'Enter a valid telephone number.';
    const interest = D.fields[b.interest] || (b.interest === 'other' ? 'Another discipline' : 'Not sure yet');
    const contribution = D.contribution_ranges.includes(b.contribution) ? b.contribution : '';
    const message = C.cleanText(b.message, 5000);
    if (message.length < 5) errors.message = 'Write a short message so we know how to help.';
    let subject;
    if (type === 'partnership') {
      if (!org) errors.organization = 'Enter your organization’s name.';
      const pt = D.partnership_types.includes(b.partnership_type) ? b.partnership_type : 'Not sure yet';
      subject = 'Partnership inquiry: ' + pt; kind = 'partnership inquiry';
      Object.assign(rows, { Organization: org || '—', Telephone: phone || '—', 'Partnership type': pt });
    } else {
      subject = D.subjects[b.subject] || D.subjects.general;
      Object.assign(rows, { Organization: org || '—', Telephone: phone || '—' });
    }
    Object.assign(rows, { Subject: subject, 'Research interest': interest, 'Estimated contribution': contribution || 'Not specified', Message: message });
    subjectLine = subject; confirm = { Subject: subject, 'Research interest': interest };
  }
  if (Object.keys(errors).length) return respond(false, 'Please correct the highlighted fields.', errors, 422);
  rows['Sent from'] = C.cleanLine(C.header(event, 'referer'), 300) || C.SITE() + '/';
  const to = C.recipients();
  try {
    await C.mail(to, '[Website] ' + subjectLine + ' — ' + name, 'New ' + kind, 'Reply to this email to answer ' + C.esc(name) + ' directly.', rows, '', [email, name], { 'X-Auto-Response-Suppress': 'OOF, AutoReply' });
  } catch (e) {
    console.error('Inquiry email failed:', e.message);
    return respond(false, 'We couldn’t send your message right now. Please email us at ' + D.contact_email + '.', {}, 500);
  }
  try {
    const first = (name.split(' ')[0] || '').match(/^[\p{L}'’.\-]{1,40}$/u) ? name.split(' ')[0] : '';
    await C.mail([email], 'We’ve received your ' + kind + ' — ' + D.short_name, 'Thank you' + (first ? ', ' + first : ''),
      'Thank you for contacting ' + C.esc(D.org_name) + '. We’ve received your ' + kind + ' and a member of our team will reply by email.', confirm,
      'If you need to add anything, simply reply to this email.', [to[0], D.short_name], { 'Auto-Submitted': 'auto-replied', 'X-Auto-Response-Suppress': 'All' });
  } catch (e) { console.error('Auto-reply failed:', e.message); }
  return respond(true, 'Thank you. Your message has been received.');
};
