'use strict';
/* Stripe webhook → emails the team when a donation completes (no database on Netlify). */
const crypto = require('crypto');
const C = require('../lib/common.js');

function verify(payload, header, secret) {
  let ts = 0; const sigs = [];
  for (const part of String(header || '').split(',')) { const [k, v] = part.trim().split('='); if (k === 't') ts = parseInt(v, 10); else if (k === 'v1' && v) sigs.push(v); }
  if (!ts || !sigs.length || Math.abs(Date.now() / 1000 - ts) > 300) return false;
  const exp = Buffer.from(crypto.createHmac('sha256', secret).update(ts + '.' + payload).digest('hex'));
  return sigs.some((s) => { const b = Buffer.from(s); return b.length === exp.length && crypto.timingSafeEqual(b, exp); });
}
exports.handler = async (event) => {
  const secret = C.env('STRIPE_WEBHOOK_SECRET');
  const payload = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
  if (!secret || !verify(payload, C.header(event, 'stripe-signature'), secret)) return { statusCode: 400, body: 'Invalid signature' };
  let ev; try { ev = JSON.parse(payload); } catch (e) { return { statusCode: 400, body: 'Invalid payload' }; }
  const o = (ev.data && ev.data.object) || {};
  let rec = null;
  if (ev.type === 'checkout.session.completed' || ev.type === 'checkout.session.async_payment_succeeded') {
    const m = o.metadata || {};
    rec = { kind: 'donation', amount: (o.amount_total || 0) / 100, status: o.payment_status || 'paid', frequency: m.frequency || (o.mode === 'subscription' ? 'recurring' : 'one-time'), interest: m.research_interest || '', name: (o.customer_details || {}).name || '', email: (o.customer_details || {}).email || o.customer_email || '' };
  } else if (ev.type === 'invoice.paid' && o.billing_reason === 'subscription_cycle') {
    const m = (o.subscription_details && o.subscription_details.metadata) || (o.parent && o.parent.subscription_details && o.parent.subscription_details.metadata) || {};
    rec = { kind: 'recurring gift', amount: (o.amount_paid || 0) / 100, status: 'paid', frequency: m.frequency || 'recurring', interest: m.research_interest || '', name: o.customer_name || '', email: o.customer_email || '' };
  }
  if (rec && C.mailConfigured()) {
    try {
      await C.mail(C.recipients(), '[Website] New ' + rec.kind + ': ' + C.money(rec.amount), 'New donation received', 'A ' + C.esc(rec.frequency) + ' gift was completed through the website.',
        { Amount: C.money(rec.amount) + ' ' + String(o.currency || 'usd').toUpperCase(), Donor: rec.name || '—', Email: rec.email || '—', 'Research interest': rec.interest || '—', 'Payment status': rec.status, 'Stripe reference': o.id || '' });
    } catch (e) { console.error('Donation email failed', e.message); }
  }
  return { statusCode: 200, body: 'ok' };
};
