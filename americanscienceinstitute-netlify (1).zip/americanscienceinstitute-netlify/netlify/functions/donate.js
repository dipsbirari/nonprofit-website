'use strict';
/* Creates a Stripe Checkout Session (one-time, monthly, annual). Mirrors api/donate.php. */
const C = require('../lib/common.js');
const D = C.DATA;

function form(obj, prefix, out) {
  out = out || new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    const key = prefix ? prefix + '[' + k + ']' : k;
    if (v !== null && typeof v === 'object') form(v, key, out); else if (v !== undefined) out.append(key, String(v));
  }
  return out;
}
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return C.json(405, { ok: false, message: 'Method not allowed.' });
  const b = C.parseBody(event), asJson = C.wantsJson(event);
  const fail = (message, status) => asJson ? C.json(status || 400, { ok: false, message }) : { statusCode: 303, headers: { Location: '/donate/?error=1#donate-form' }, body: '' };
  const spam = C.spamCheck(b);
  if (spam === 'bot') return fail('We couldn’t start the checkout. Please try again.');
  if (spam) return fail(spam);
  if (!(await C.verifyRecaptcha(b.recaptcha_token, 'donate', C.header(event, 'x-nf-client-connection-ip')))) return fail('We could not verify that this request came from a person. Please refresh the page and try again.');
  const key = C.env('STRIPE_SECRET_KEY');
  if (D.donation.processor !== 'stripe' || !/^(sk|rk)_(live|test)_/.test(key)) return fail('Online donations are not available at the moment. Please contact us and we will help you make your gift.', 503);
  const min = Math.max(1, D.donation.min);
  const amount = Math.round(parseFloat(b.amount_choice === 'other' ? String(b.amount_custom || '').replace(/[^0-9.]/g, '') : b.amount_choice) * 100) / 100;
  if (!Number.isFinite(amount) || amount < min || amount > 999999) return fail('Enter an amount between ' + C.money(min) + ' and $999,999.');
  let freq = b.frequency;
  if (!((freq === 'monthly' && D.donation.monthly) || (freq === 'annual' && D.donation.annual))) freq = 'one-time';
  const interest = D.fields[b.interest] || 'Where it is needed most';
  let fee = 0;
  if (b.cover_fees && D.donation.cover_fees) fee = Math.round(((amount + D.donation.fee_fixed) / (1 - D.donation.fee_percent / 100) - amount) * 100) / 100;
  const label = { 'one-time': 'One-time donation', monthly: 'Monthly donation', annual: 'Annual donation' }[freq];
  const meta = { gift_amount: amount.toFixed(2), fees_covered: fee.toFixed(2), frequency: freq, research_interest: interest, source: 'website' };
  const p = {
    mode: freq === 'one-time' ? 'payment' : 'subscription',
    line_items: { 0: { quantity: 1, price_data: { currency: D.donation.currency, unit_amount: Math.round((amount + fee) * 100), product_data: { name: label + ' to ' + D.org_name, description: 'Research interest: ' + interest } } } },
    success_url: C.SITE() + '/donation-thank-you/?session_id={CHECKOUT_SESSION_ID}',
    cancel_url: C.SITE() + '/donate/?canceled=1#donate-form',
    metadata: meta, billing_address_collection: 'auto',
  };
  if (freq === 'one-time') Object.assign(p, { submit_type: 'donate', customer_creation: 'always', payment_intent_data: { description: label + ' — ' + interest, metadata: meta } });
  else { p.line_items[0].price_data.recurring = { interval: freq === 'monthly' ? 'month' : 'year' }; p.subscription_data = { description: label + ' — ' + interest, metadata: meta }; }
  try {
    const r = await fetch('https://api.stripe.com/v1/checkout/sessions', { method: 'POST', body: form(p),
      headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/x-www-form-urlencoded', 'Idempotency-Key': require('crypto').randomBytes(16).toString('hex') } });
    const d = await r.json();
    if (!r.ok || !d.url) { console.error('Stripe error', r.status, d.error && d.error.message); return fail('We couldn’t start the secure checkout. Please try again in a moment.', 502); }
    return asJson ? C.json(200, { ok: true, url: d.url }) : { statusCode: 303, headers: { Location: d.url }, body: '' };
  } catch (e) { console.error('Stripe unreachable', e.message); return fail('We couldn’t start the secure checkout. Please try again in a moment.', 502); }
};
