# Netlify deployment — AmericanScienceInstitute.org

This folder is the **Netlify version** of the website. It has pre-rendered pages in `public/`, and serverless functions in `netlify/functions/` for the forms, SMTP email, reCAPTCHA and Stripe. The functions need **no npm install**.

> Netlify cannot run PHP. The website admin (`/admin/`) is therefore only available on Hostinger.
> To change content for Netlify:
> 1. Edit it in the admin (Hostinger, or locally with XAMPP).
> 2. Run `php tools/export-netlify.php`.
> 3. Redeploy.

## Deploy (choose one)
- **Git (recommended):** push this folder to a GitHub repository. Then in Netlify use **Add new site → Import an existing project**. `netlify.toml` already sets the publish folder and functions.
- **Netlify CLI:** run `npm install -g netlify-cli`, then `netlify login`. From this folder run `netlify deploy --prod`.
- **Not supported:** Drag-and-drop of `public/` publishes the pages only. Forms and donations will not work, because functions are not deployed that way.

## Environment variables (Site configuration → Environment variables)
| Variable | Value |
| --- | --- |
| `SMTP_HOST` | Mail server, e.g. `smtp.hostinger.com` (Hostinger Email) |
| `SMTP_PORT` | `465` (or `587`) |
| `SMTP_SECURE` | `ssl` for 465, `tls` for 587 |
| `SMTP_USER` | `support@americanscienceinstitute.org` |
| `SMTP_PASS` | mailbox password |
| `MAIL_FROM` | `support@americanscienceinstitute.org` |
| `MAIL_FROM_NAME` | `American Science Institute` |
| `MAIL_TO` | `support@americanscienceinstitute.org` (comma-separate for more) |
| `RECAPTCHA_SECRET` | reCAPTCHA v3 secret key |
| `STRIPE_SECRET_KEY` | `sk_live_…` (or `sk_test_…` while testing) |
| `STRIPE_WEBHOOK_SECRET` | `whsec_…` from the Stripe webhook below |
| `SITE_URL` | `https://americanscienceinstitute.org` |

**Public keys:** the reCAPTCHA *site* key and the Google Analytics ID go in `public/site-config.js`. Edit that file, then redeploy.

**Stripe webhook:**
1. Add the endpoint `https://americanscienceinstitute.org/api/stripe-webhook.php`.
2. Choose the events `checkout.session.completed`, `checkout.session.async_payment_succeeded` and `invoice.paid`.
3. On Netlify, completed donations are emailed to you. The donations history stays in your Stripe Dashboard.

## Domain and email DNS
1. In Netlify, go to Domain management, add `americanscienceinstitute.org`, and make it the primary domain. `www` redirects to it automatically.
2. If you move the domain's DNS to Netlify, re-create the **email records** there exactly as your mail provider lists them. Otherwise email stops working.
   - **MX** records.
   - **SPF** TXT.
   - **DKIM**.
   - **DMARC** TXT.
3. See the main README → *Email deliverability* for the exact records.
