/* American Institute for Scientific Advancement Corp. — site.js v3 (vanilla JavaScript, no dependencies) */
window.ASI=window.ASI||{};

/* ===== Core: header, reveal, menus, accordions, counters, timeline, wizard ===== */
(function(){
'use strict';
var d=document,W=window,root=d.documentElement,ASI=W.ASI=W.ASI||{};
var reduce=W.matchMedia('(prefers-reduced-motion: reduce)').matches;ASI.reduce=reduce;
function each(s,f,c){[].forEach.call((c||d).querySelectorAll(s),f);}
root.classList.add('js');

/* Header shadow, reading progress, back-to-top (no hiding or resizing on scroll) */
var header=d.querySelector('.site-header'),prog=d.querySelector('.scroll-progress'),toTop=d.querySelector('.to-top'),hooks=[],ticking=false;
ASI.onScroll=function(f){hooks.push(f);};
function frame(){ticking=false;var y=W.scrollY||0,vh=W.innerHeight,max=Math.max(1,root.scrollHeight-vh),p=Math.min(1,y/max);
  if(header)header.classList.toggle('is-scrolled',y>8);
  if(prog)prog.style.transform='scaleX('+p.toFixed(4)+')';
  if(toTop){toTop.classList.toggle('is-visible',y>vh*.8);toTop.style.setProperty('--p',p.toFixed(3));}
  hooks.forEach(function(h){h(y,vh);});}
function req(){if(!ticking){ticking=true;requestAnimationFrame(frame);}}
W.addEventListener('scroll',req,{passive:true});W.addEventListener('resize',req);
if(toTop)toTop.addEventListener('click',function(){W.scrollTo({top:0,behavior:reduce?'auto':'smooth'});});

/* Mobile menu + Research dropdown */
var tog=d.querySelector('.menu-toggle'),nav=d.getElementById('site-nav');
function closeMenu(){if(!nav)return;nav.classList.remove('open');if(tog){tog.setAttribute('aria-expanded','false');tog.setAttribute('aria-label','Open menu');}d.body.classList.remove('menu-open');}
if(tog&&nav){tog.addEventListener('click',function(){var o=!nav.classList.contains('open');nav.classList.toggle('open',o);tog.setAttribute('aria-expanded',String(o));tog.setAttribute('aria-label',o?'Close menu':'Open menu');d.body.classList.toggle('menu-open',o);});
  nav.addEventListener('click',function(e){if(e.target.closest('a'))closeMenu();});
  d.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){closeMenu();tog.focus();}});}
each('.nav-group',function(g){var b=g.querySelector('.nav-parent');if(!b)return;var mq=W.matchMedia('(max-width: 1180px)');
  var set=function(o){g.classList.toggle('open',o);b.setAttribute('aria-expanded',String(o));};
  b.addEventListener('click',function(){set(!g.classList.contains('open'));});
  g.addEventListener('focusout',function(e){if(!g.contains(e.relatedTarget)&&!mq.matches)set(false);});
  d.addEventListener('click',function(e){if(!g.contains(e.target)&&!mq.matches)set(false);});
  g.addEventListener('keydown',function(e){if(e.key==='Escape'&&g.classList.contains('open')){set(false);b.focus();}});});

/* Reveal on scroll: only content below the fold is hidden first, with a safety net */
var targets=[].slice.call(d.querySelectorAll('[data-reveal],[data-split],[data-lines]'));
each('[data-stagger]',function(g){var k=0;[].forEach.call(g.children,function(c){if(c.matches('[data-reveal]'))c.style.setProperty('--rd',Math.min(k++*80,480)+'ms');});});
ASI.reveal=function(el){el.classList.add('rv-in');};
if(!reduce&&'IntersectionObserver' in W){
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('rv-in');io.unobserve(e.target);}});},{rootMargin:'0px 0px -6% 0px',threshold:.06});
  var vh=W.innerHeight;
  targets.forEach(function(el){if(el.matches('figure,picture,img')||el.querySelector('img,picture'))return;if(el.getBoundingClientRect().top>vh*.9){el.classList.add('rv');io.observe(el);}});
  W.addEventListener('load',function(){setTimeout(function(){each('.rv:not(.rv-in)',function(el){var r=el.getBoundingClientRect();if(r.top<W.innerHeight&&r.bottom>0)el.classList.add('rv-in');});},1200);});
}
/* Elements that animate once in view (reaction arrows) */
if('IntersectionObserver' in W){var io2=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-in');io2.unobserve(e.target);}});},{threshold:.3});
  each('[data-observe]',function(el){if(reduce)el.classList.add('is-in');else io2.observe(el);});}else each('[data-observe]',function(el){el.classList.add('is-in');});

/* Count-up numbers */
each('[data-count]',function(el){var end=parseInt(el.getAttribute('data-count'),10);if(reduce||!end||!('IntersectionObserver' in W))return;
  var o=new IntersectionObserver(function(es){if(!es[0].isIntersecting)return;o.disconnect();var t0=0;
    (function tick(t){if(!t0)t0=t;var p=Math.min(1,(t-t0)/1300);el.textContent=Math.round(end*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(tick);})(performance.now());},{threshold:.5});
  o.observe(el);});

var idle=W.requestIdleCallback||function(f){return setTimeout(f,200);};
/* Smooth accordions */
each('details[data-accordion]',function(det){var sum=det.querySelector('summary'),body=det.querySelector('.acc-body'),anim=null;if(!sum||!body)return;
  sum.addEventListener('click',function(e){if(reduce||!body.animate)return;e.preventDefault();if(anim)anim.cancel();
    if(det.open){var h=body.offsetHeight;anim=body.animate([{height:h+'px',opacity:1},{height:'0px',opacity:0}],{duration:320,easing:'cubic-bezier(.65,0,.35,1)'});
      anim.onfinish=function(){det.open=false;anim=null;};}
    else{det.open=true;var h2=body.offsetHeight;anim=body.animate([{height:'0px',opacity:0},{height:h2+'px',opacity:1}],{duration:420,easing:'cubic-bezier(.16,1,.3,1)'});anim.onfinish=function(){anim=null;};}});});

/* Timeline progress line */
each('[data-timeline]',function(tl){var steps=[].slice.call(tl.querySelectorAll('.tl-step')),mq=W.matchMedia('(max-width: 980px)');
  hooks.push(function(y,vh){var r=tl.getBoundingClientRect(),vert=mq.matches,p=reduce?1:(vert?(vh*.72-r.top)/Math.max(1,r.height):(vh*.84-r.top)/(vh*.42));
    p=Math.max(0,Math.min(1,p));tl.style.setProperty('--p',p.toFixed(3));
    steps.forEach(function(s){var b=s.querySelector('.tl-dot').getBoundingClientRect(),at=vert?(b.top+b.height/2-r.top)/r.height:(b.left+b.width/2-r.left)/r.width;s.classList.toggle('on',p>=at-.01);});});});

/* Home: rotating research questions (fade/slide, no typing) */
var ask=d.querySelector('.ask'),txt=ask&&ask.querySelector('.typer-text');
if(ask&&txt){var PH=['Finding better treatments for cancer.','Understanding the human brain.','Developing artificial intelligence.','Discovering new energy technologies.','Advancing space exploration.','Addressing climate change.'],
    FMAP=[0,0,1,3,4,3],F=[];try{F=JSON.parse((d.getElementById('asi-fields')||{}).textContent||'[]');}catch(e){}
  var segs=[].slice.call(ask.querySelectorAll('.seg')),pBtn=ask.querySelector('.pause'),idx=0,timer=0,paused=false,DUR=3800;
  var paint=function(){segs.forEach(function(s,k){s.classList.toggle('active',k===idx);s.classList.toggle('done',k<idx);s.setAttribute('aria-pressed',String(k===idx));
      var f=s.querySelector('.fill');if(!f)return;
      if(k===idx&&!paused&&!reduce){f.style.animation='none';void f.offsetWidth;f.style.transform='';f.style.animation='segFill '+DUR+'ms linear forwards';}
      else{f.style.animation='none';f.style.transform=k<idx||(k===idx&&(paused||reduce))?'scaleX(1)':'scaleX(0)';}});};
  var show=function(n,anim){idx=(n+PH.length)%PH.length;var swap=function(){txt.textContent=PH[idx];txt.classList.remove('out');};
    if(anim&&!reduce){txt.classList.add('out');setTimeout(swap,300);}else swap();paint();};
  var schedule=function(){clearTimeout(timer);if(!paused&&!reduce)timer=setTimeout(function(){show(idx+1,true);schedule();},DUR);};
  segs.forEach(function(s,k){s.addEventListener('click',function(){show(k,true);schedule();});});
  if(pBtn)pBtn.addEventListener('click',function(){paused=!paused;pBtn.setAttribute('aria-pressed',String(paused));pBtn.setAttribute('aria-label',paused?'Play examples':'Pause examples');paint();schedule();});
  var started=false;
  if('IntersectionObserver' in W)new IntersectionObserver(function(es,o){if(es[0].isIntersecting&&!started){started=true;o.disconnect();show(0,false);schedule();}},{threshold:.3}).observe(ask);else show(0,false);
  var cta=d.getElementById('ask-cta');
  if(cta)cta.addEventListener('click',function(){if(ASI.prefill&&F[FMAP[idx]])ASI.prefill({field:F[FMAP[idx]].name,question:PH[idx].replace(/\.$/,'')});});}

/* Proposal wizard */
each('[data-wizard]',function(form){
  var steps=[].slice.call(form.querySelectorAll('.wz-step')),labels=[].slice.call(form.querySelectorAll('[data-step-label]'));
  var bar=form.querySelector('.wz-bar'),back=form.querySelector('[data-wz-back]'),next=form.querySelector('[data-wz-next]'),submit=form.querySelector('[data-wz-submit]'),live=form.querySelector('[data-wz-live]'),i=0;
  function go(n,focus){var dir=n>=i?1:-1;i=Math.max(0,Math.min(steps.length-1,n));
    steps.forEach(function(s,k){s.classList.toggle('is-current',k===i);s.style.setProperty('--dir',dir);});
    labels.forEach(function(l,k){l.classList.toggle('is-done',k<i);l.classList.toggle('is-current',k===i);if(k===i)l.setAttribute('aria-current','step');else l.removeAttribute('aria-current');});
    if(bar)bar.style.transform='scaleX('+((i+1)/steps.length)+')';
    back.hidden=i===0;next.hidden=i===steps.length-1;submit.hidden=i!==steps.length-1;
    if(live)live.textContent='Step '+(i+1)+' of '+steps.length;
    if(i===steps.length-1)summary();
    if(focus){var f=steps[i].querySelector('textarea,input:not([type=radio]),select')||steps[i].querySelector('input');if(f)f.focus({preventScroll:true});}}
  function validate(step){var first=null;
    each('[required]',function(f){var bad;
      if(f.type==='radio')bad=!form.querySelector('input[name="'+f.name+'"]:checked');
      else{var v=f.value.trim();bad=!v||(f.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));f.setAttribute('aria-invalid',bad?'true':'false');}
      var err=form.querySelector('[data-error-for="'+f.name+'"]');if(err)err.hidden=!bad;if(bad&&!first)first=f;},step);
    if(first){first.focus();return false;}return true;}
  function summary(){var s=form.querySelector('[data-summary]');if(!s)return;var fd=new FormData(form);s.innerHTML='';
    [['Research field',fd.get('field')],['Research question',fd.get('question')],['Type of support',fd.get('support')],['Intended contribution',fd.get('amount')||'Not specified']]
    .forEach(function(r){var dt=d.createElement('dt');dt.textContent=r[0];var dd=d.createElement('dd');dd.textContent=r[1]||'Not specified';s.appendChild(dt);s.appendChild(dd);});}
  next.addEventListener('click',function(){if(validate(steps[i]))go(i+1,true);});
  back.addEventListener('click',function(){go(i-1,true);});
  form.addEventListener('change',function(e){if(e.target.name==='field'){var er=form.querySelector('[data-error-for="field"]');if(er)er.hidden=true;}});
  var q=form.querySelector('[name="question"]');q.addEventListener('input',function(){q.removeAttribute('data-auto');});
  form.addEventListener('submit',function(e){e.preventDefault();if(!validate(steps[i]))return;if(!ASI.send)return;
    ASI.send(form,'proposal').then(function(res){
      if(!res.ok){var k=Object.keys(res.errors||{})[0],f=k&&form.querySelector('[name="'+k+'"]'),st=f&&f.closest('.wz-step'),ix=steps.indexOf(st);if(ix>-1&&ix!==i)go(ix,true);return;}
      ASI.formSuccess(form);if(W.gtag)W.gtag('event','generate_lead',{form_type:'proposal'});});});
  ASI.prefill=function(o){o=o||{};
    if(o.field)each('input[name="field"]',function(r){if(r.value===o.field)r.checked=true;},form);
    if(o.support){var sel=form.querySelector('[name="support"]');if(sel)sel.value=o.support;}
    if(o.question&&(!q.value.trim()||q.getAttribute('data-auto')==='1')){q.value=o.question;q.setAttribute('data-auto','1');}
    go(o.field?1:0,false);};
  go(parseInt(form.getAttribute('data-start'),10)||0,false);
});
d.addEventListener('click',function(e){var a=e.target.closest('[data-prefill-field],[data-prefill-support],[data-prefill-question]');
  if(!a||!ASI.prefill)return;ASI.prefill({field:a.getAttribute('data-prefill-field'),support:a.getAttribute('data-prefill-support'),question:a.getAttribute('data-prefill-question')});});
/* Load the 3D globe only when it is about to scroll into view */
var gl=d.querySelector('[data-globe][data-src]');
if(gl){var loadG=function(){if(gl.getAttribute('data-loaded'))return;gl.setAttribute('data-loaded','1');var sc=d.createElement('script');sc.src=gl.getAttribute('data-src');sc.async=true;d.body.appendChild(sc);};
  if('IntersectionObserver' in W){var gio=new IntersectionObserver(function(es){if(es[0].isIntersecting){gio.disconnect();loadG();}},{rootMargin:'700px 0px'});gio.observe(gl);}else loadG();}
frame();
W.ASI_READY=true;
})();

/* ===== Forms, reCAPTCHA v3, donations, consent & analytics ===== */
(function(){
'use strict';
var d=document,W=window,root=d.documentElement,ASI=W.ASI=W.ASI||{};
function each(sel,fn,ctx){[].forEach.call((ctx||d).querySelectorAll(sel),fn);}

/* reCAPTCHA loads only when someone starts using a form (keeps pages fast) */
var CFG=W.ASI_CONFIG||{},T0=Date.now(),RKEY=root.getAttribute('data-recaptcha')||CFG.recaptchaSiteKey||'',rP=null;
if(RKEY)each('.rc-note',function(n){n.hidden=false;});
function loadRecaptcha(){
  if(!RKEY)return Promise.resolve(null);
  if(rP)return rP;
  rP=new Promise(function(res){var s=d.createElement('script');s.src='https://www.google.com/recaptcha/api.js?render='+encodeURIComponent(RKEY);s.async=true;
    s.onload=function(){if(W.grecaptcha&&W.grecaptcha.ready)W.grecaptcha.ready(function(){res(W.grecaptcha);});else res(null);};
    s.onerror=function(){rP=null;res(null);};d.head.appendChild(s);});
  return rP;}
function token(action){return loadRecaptcha().then(function(g){if(!g)return '';
  return new Promise(function(res){try{g.execute(RKEY,{action:action}).then(res,function(){res('');});}catch(e){res('');}});});}
each('form[data-ajax],form[data-wizard],form[data-donate]',function(f){f.addEventListener('focusin',loadRecaptcha,{once:true});f.addEventListener('pointerenter',loadRecaptcha,{once:true});});

function showErrors(form,errs){var first=null;
  Object.keys(errs||{}).forEach(function(k){var f=form.querySelector('[name="'+k+'"]'),er=form.querySelector('[data-error-for="'+k+'"]');
    if(er){er.textContent=errs[k];er.hidden=false;}if(f&&f.type!=='radio')f.setAttribute('aria-invalid','true');if(!first&&f)first=f;});
  if(first&&first.offsetParent!==null)first.focus();}

/* POST a form as FormData and return the JSON response */
function send(form,action){
  var st=form.querySelector('.form-status'),btns=form.querySelectorAll('[type=submit]');
  if(st)st.hidden=true;
  [].forEach.call(btns,function(b){b.disabled=true;});form.setAttribute('aria-busy','true');
  return token(action).then(function(t){var tf=form.querySelector('[name=recaptcha_token]');if(tf)tf.value=t;
      var fd=new FormData(form);fd.set('elapsed',String(Date.now()-T0));return fetch(form.action,{method:'POST',body:new URLSearchParams(fd),headers:{'Accept':'application/json'},credentials:'same-origin'});})
    .then(function(r){return r.json().catch(function(){return {ok:false,message:'Something went wrong on our side. Please try again.'};});},
          function(){return {ok:false,message:'We couldn’t reach the server. Check your connection and try again.'};})
    .then(function(res){[].forEach.call(btns,function(b){b.disabled=false;});form.removeAttribute('aria-busy');
      if(!res.ok){if(res.errors)showErrors(form,res.errors);if(st&&res.message){st.textContent=res.message;st.hidden=false;}}
      return res;});}
ASI.send=send;

var EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
function validateFields(scope){var first=null;
  each('input,select,textarea',function(f){if(!f.name||f.type==='hidden'||f.type==='radio'||f.type==='checkbox'||(f.closest&&f.closest('.hp')))return;
    var v=(f.value||'').trim(),bad=f.required&&!v;
    if(!bad&&v&&f.type==='email')bad=!EMAIL.test(v);
    if(!bad&&v&&f.type==='tel')bad=!/^[0-9+().\-\s]{7,40}$/.test(v);
    f.setAttribute('aria-invalid',bad?'true':'false');
    var er=scope.querySelector('[data-error-for="'+f.name+'"]');if(er)er.hidden=!bad;
    if(bad&&!first)first=f;},scope);
  if(first){first.focus();return false;}return true;}

function success(form){var body=form.querySelector('.form-body,.wz-body'),ok=form.querySelector('.wz-success');
  if(body)body.hidden=true;if(ok){ok.hidden=false;ok.focus({preventScroll:true});ok.scrollIntoView({block:'center',behavior:ASI.reduce?'auto':'smooth'});}}
ASI.formSuccess=success;

each('form[data-ajax]',function(form){
  form.addEventListener('input',function(e){if(e.target.getAttribute('aria-invalid')==='true'){e.target.setAttribute('aria-invalid','false');var er=form.querySelector('[data-error-for="'+e.target.name+'"]');if(er)er.hidden=true;}});
  form.addEventListener('submit',function(e){e.preventDefault();if(!validateFields(form))return;var type=(form.querySelector('[name=form_type]')||{}).value||'contact';
    send(form,type).then(function(res){if(!res.ok)return;success(form);if(W.gtag)W.gtag('event','generate_lead',{form_type:type});});});
});

/* Donation form: amounts, frequency, optional processing fee, Stripe Checkout redirect */
each('form[data-donate]',function(form){
  var min=parseFloat(form.getAttribute('data-min'))||5,pct=parseFloat(form.getAttribute('data-fee-pct'))||2.9,fix=parseFloat(form.getAttribute('data-fee-fixed'))||.3;
  var custom=form.querySelector('[data-custom]'),amt=form.querySelector('[name=amount_custom]'),total=form.querySelector('[data-total]'),feeEl=form.querySelector('[data-fee]'),
      freqEl=form.querySelector('[data-freq-label]'),cover=form.querySelector('[name=cover_fees]'),err=form.querySelector('[data-error-for="amount"]');
  var LBL={'one-time':'one time','monthly':'monthly','annual':'annually'};
  function base(){var c=form.querySelector('[name=amount_choice]:checked');if(!c)return 0;
    if(c.value==='other'){var v=parseFloat(String(amt.value||'').replace(/[^0-9.]/g,''));return isFinite(v)?v:0;}return parseFloat(c.value)||0;}
  function fee(a){return a>0?Math.round(((a+fix)/(1-pct/100)-a)*100)/100:0;}
  function fmt(n){return '$'+n.toLocaleString('en-US',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2});}
  function update(){var c=form.querySelector('[name=amount_choice]:checked');if(custom)custom.hidden=!(c&&c.value==='other');
    var a=base(),f=fee(a);if(feeEl)feeEl.textContent=fmt(f);if(total)total.textContent=fmt(Math.round((a+(cover&&cover.checked?f:0))*100)/100);
    var fr=form.querySelector('[name=frequency]:checked')||form.querySelector('[name=frequency]');if(freqEl&&fr)freqEl.textContent=LBL[fr.value]||'';}
  form.addEventListener('change',function(e){update();if(e.target.name==='amount_choice'&&e.target.value==='other'&&amt)amt.focus();if(err)err.hidden=true;});
  if(amt)amt.addEventListener('input',function(){update();if(err)err.hidden=true;});
  update();
  form.addEventListener('submit',function(e){e.preventDefault();var a=base();
    if(!(a>=min)){if(err)err.hidden=false;var c=form.querySelector('[name=amount_choice]:checked');(c&&c.value==='other'?amt:form.querySelector('[name=amount_choice]')).focus();return;}
    send(form,'donate').then(function(res){if(res.ok&&res.url){if(W.gtag)W.gtag('event','begin_checkout',{currency:'USD',value:a});
      [].forEach.call(form.querySelectorAll('[type=submit]'),function(b){b.disabled=true;});W.location.href=res.url;}});});
});

/* Analytics only after consent; Global Privacy Control counts as "decline" */
var GA=root.getAttribute('data-ga')||CFG.ga4Id||'',banner=d.getElementById('consent');
if(GA)each('[data-consent-open]',function(b){b.hidden=false;});
function loadGA(){if(!GA||W.gtag)return;W.dataLayer=W.dataLayer||[];W.gtag=function(){W.dataLayer.push(arguments);};
  W.gtag('js',new Date());W.gtag('config',GA);var s=d.createElement('script');s.async=true;s.src='https://www.googletagmanager.com/gtag/js?id='+encodeURIComponent(GA);d.head.appendChild(s);}
function getC(){try{return localStorage.getItem('asi-consent');}catch(e){return null;}}
function setC(v){try{localStorage.setItem('asi-consent',v);}catch(e){}}
if(GA){var c=getC();if(!c&&navigator.globalPrivacyControl)c='denied';
  if(c==='granted')loadGA();else if(!c&&banner)banner.hidden=false;
  d.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-consent],[data-consent-open]');if(!b)return;
    if(b.hasAttribute('data-consent-open')){if(banner){banner.hidden=false;var f=banner.querySelector('button');if(f)f.focus();}return;}
    var v=b.getAttribute('data-consent');setC(v);if(banner)banner.hidden=true;if(v==='granted')loadGA();else W['ga-disable-'+GA]=true;});}

/* Research areas: highlight the field in view */
var an=[].slice.call(d.querySelectorAll('.areas-nav a'));
if(an.length&&'IntersectionObserver' in W){var map={};an.forEach(function(a){map[a.getAttribute('href').slice(1)]=a;});
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting)an.forEach(function(a){a.classList.toggle('is-active',a===map[e.target.id]);});});},{rootMargin:'-30% 0px -60% 0px'});
  Object.keys(map).forEach(function(id){var s=d.getElementById(id);if(s)io.observe(s);});}

/* Copy-link buttons */
d.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-copy]');if(!b)return;var u=b.getAttribute('data-copy');
  var done=function(){b.classList.add('copied');b.setAttribute('aria-label','Link copied');setTimeout(function(){b.classList.remove('copied');b.setAttribute('aria-label','Copy link');},2000);};
  if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(u).then(done,function(){W.prompt('Copy this link',u);});else W.prompt('Copy this link',u);});
})();

/* ===== URL parameters: preselect form choices, show notices, filter news on static hosting ===== */
(function(){
'use strict';
var d=document,W=window,ASI=W.ASI||{},P=new URLSearchParams(W.location.search);
function each(sel,fn,ctx){[].forEach.call((ctx||d).querySelectorAll(sel),fn);}
each('[data-param]',function(n){if(P.has(n.getAttribute('data-param')))n.hidden=false;});
function setSel(sel,val){if(!val)return;each(sel,function(s){for(var i=0;i<s.options.length;i++){var o=s.options[i];if(o.value===val||o.text===val){s.value=o.value;break;}}});}
setSel('select[name=subject]',P.get('subject'));setSel('select[name=interest]',P.get('interest'));setSel('select[name=partnership_type]',P.get('type'));setSel('select[name=support]',P.get('support'));
var fq=(P.get('frequency')||'').replace(/[^a-z-]/g,'');
if(fq)each('input[name=frequency][value="'+fq+'"]',function(r){r.checked=true;r.dispatchEvent(new Event('change',{bubbles:true}));});
var fk=(P.get('field')||'').replace(/[^a-z]/g,'');
if(fk){var r=d.querySelector('input[name=field][data-key="'+fk+'"]');if(r){r.checked=true;if(ASI.prefill)ASI.prefill({field:r.value});}}
var NS=d.querySelector('[data-news-static]');
if(NS){
  var items=[].slice.call(NS.querySelectorAll('.news-item')),topics=[].slice.call(NS.querySelectorAll('.topic')),form=NS.querySelector('.search'),
      input=form&&form.querySelector('input[name=q]'),note=NS.querySelector('[data-results]'),empty=NS.querySelector('[data-empty]'),names={},cur='';
  topics.forEach(function(t){names[t.getAttribute('data-cat')]=t.querySelector('strong').textContent;});
  var apply=function(cat,q,push){q=(q||'').trim();var lq=q.toLowerCase(),n=0;
    items.forEach(function(it){var ok=(!cat||it.getAttribute('data-cat')===cat)&&(!lq||it.getAttribute('data-text').indexOf(lq)>-1);it.hidden=!ok;if(ok){n++;if(ASI.reveal)ASI.reveal(it);}});
    topics.forEach(function(t){if(t.getAttribute('data-cat')===cat)t.setAttribute('aria-current','true');else t.removeAttribute('aria-current');});
    if(empty)empty.hidden=n>0;
    if(note){note.textContent='';if(cat||q){note.appendChild(d.createTextNode((cat?'Showing '+names[cat]+'. ':'')+(q?n+' result'+(n===1?'':'s')+' for “'+q+'”. ':'')));
      var a=d.createElement('a');a.href=W.location.pathname;a.className='text-link';a.textContent='Show all articles';
      a.addEventListener('click',function(e){e.preventDefault();cur='';if(input)input.value='';apply('','',true);});note.appendChild(a);}}
    if(push){var u=new URLSearchParams();if(cat)u.set('category',cat);if(q)u.set('q',q);history.replaceState(null,'',W.location.pathname+(u.toString()?'?'+u:''));}};
  cur=P.get('category')||'';if(!names[cur])cur='';if(input)input.value=P.get('q')||'';
  apply(cur,input?input.value:'',false);
  topics.forEach(function(t){t.addEventListener('click',function(e){e.preventDefault();var c=t.getAttribute('data-cat');cur=cur===c?'':c;apply(cur,input?input.value:'',true);});});
  if(form)form.addEventListener('submit',function(e){e.preventDefault();apply(cur,input.value,true);});
}
})();
