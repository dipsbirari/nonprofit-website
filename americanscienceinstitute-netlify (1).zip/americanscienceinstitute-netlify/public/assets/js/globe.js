/* 3D dotted globe (home page) */
/* ===== 3D dotted globe echoing the emblem: Earth, two orbital rings, electrons, connection arcs ===== */
(function(){
'use strict';
var d=document,W=window,reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,TAU=Math.PI*2;
var B64='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//gAAD//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//////Hf///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/////////////AAAAAAAAAAAAAAAAAHAAAAAAAAAAAAAAAAAAAAAAAAAAAB/////////////wAAAAX/8AAP8AAAAAAfwAAAAAAAAAAAAAAAAAAAAAAAAAOB////g////////AAAAD//wAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAeP3vv/7////////+AAAAB//AAAAAAAAAAAAf8AAAAAAAAAAAAAAAAAAAAAA8+AL4f/g////////+AAAAAfvgAAAAAAAAAAAF+AAAAAAAAAAAAAAAAAAAAAH/3R////gP////////AAAAAHAAAAAAAf4AAAHP//AAAA8AAAAAAAAAAAAAAACP/5///8AAAf/////+AAAAAAAAAAAAf+AAAH////gAAD//gAAAAAAAAAAAAAf4+AN//+AAAP/////+AAAAAAAAAAAAeAAAAP///4AAAA/nAAAAAAAAAAAAAAf/B8///3wAAH/////8AAAAAAAAAAAB4AEAP//////H4AfAAAAAAAAAAAAAAA//+5/9//4AAD/////wAAAAAAAAAAAHwAHt////////8Af/AAAAA4AABgAAAA///8f8///AAD/////wAAAAAAAiAAAHwA//////////8///gQAADwAA//+gAOYf//1+///+AB/////4AAAAAAH/wAAB8A/v/////////////8AIDAAD///+P/////v/j///AB////+AAAAAAAf//gAAA+/////////////////P+4Af//////////H/z4f/AAf///4AAAAAAD///4eB//////////////////////AH/////////////45/wA///8AAAAAAAP////e///////////////////////4f/////////////gD/+A///wAycAAAAf//////////////////////////////////////////7g/+4Af//AB/+AAAA/+f+f///////////////////////jwf/////////////9//oAf/wAA/8AAAD/8//////////////////////////APH////////////PcB/wAP/gAAfgAAAP/3/////////////////////////+ACP////////////A///gAD/AAAAAAAB//H//////////////////////////AAf///////////wAG/5AAD/AAAAAAAD//H/////////////////////////gAA////////////wAA/4QAB+AAAAAAAB//n//////////////////////D/+AAAb/zwn///////wAA/44AAAAAAAAAAB//D//////////////////////D6IAAAAv4AA///////4AB//8AAAAAAAAA4B5/B///////////////////4AYPgAAAAAH8AAD///////AAf/8AAAAAAAAA+AP+H///////////////////gAA/wAAAAAfQAAB///////wAf/+AAAAAAAAB8AO8H///////////////////AAB/wAAAAD8AAAA////////x///gAAAAAAAD8AP4H//////////////////+AAB/AAAAAGAAAAD////////z///4AAAAAAAH/AP////////////////////+yAB/gAAAAAAAAADP///////x///+AAAAAAAPfj//////////////////////+AB+AAAAAAAAAABv///////5///+AAAAAAAPfz///////////////////////AA4AAAAAAAAAAAD///////////+AAAAAAAM/////////////////////////AA4AAAAAAAAAAAH///////////MAAAAAAAA////////////////////////7AAAAAAAAAAAAAAH//////////+fgAAAAAAAj///////////////////////7AAAAAAAAAAAAAAA//////////w/wAAAAAAAf///////////////////////+gAAAAAAAAAAAAAAf/////////x/wAAAAAAAf////////7//////////////yAAAAAAAAAAAAAAAf/////////9DgAAAAAAAD////////g//////////////nAAAAAAAAAAAAAAAP//////////gAAAAAAAAD/////P/+A/////////////+GAAAAAAAAAAAAAAAP/////////4AAAAAAAAAD/////Hf8D/////////////8HQAAAAAAAAAAAAAAf////////5gAAAAAAAAP//3z/+AH+D/////////////8PwAAAAAAAAAAAAAAf////////wAAAAAAAAAH/4P5/8HB+A////////////+wfgAAAAAAAAAAAAAAf////////4AAAAAAAAAP/8M+f//n/Af///////////8AdAAAAAAAAAAAAAAAf////////gAAAAAAAAAH/gMP/////gf///////////8AcAAAAAAAAAAAAAAAP///////8AAAAAAAAAAP/AMH/P///g///////////fwAMAAAAAAAAAAAAAAAP///////8AAAAAAAAAAP/gI/Pv///A//////////+T4AYAAAAAAAAAAAAAAAH///////4AAAAAAAAAAH/A3+Hn///g///////////78C4AAAAAAAAAAAAAAAD///////4AAAAAAAAAAH8//MHH///w///////////48D4AAAAAAAAAAAAAAAB///////4AAAAAAAAAAB//+AB4P//////////////A8/4AAAAAAAAAAAAAAAB///////wAAAAAAAAAAB//+AAgP//////////////g7/gAAAAAAAAAAAAAAAAf//////AAAAAAAAAAAH///AAAB//////////////gH8AAAAAAAAAAAAAAAAAP/////8AAAAAAAAAAAP///8PAD//////////////wHwAAAAAAAAAAAAAAAAAH/////4AAAAAAAAAAAP///+f/7//////////////wDAAAAAAAAAAAAAAAAAAH/////4AAAAAAAAAAAP/////////////////////wAAAAAAAAAAAAAAAAAAAD////i8AAAAAAAAAAAf/////////////////////4AAAAAAAAAAAAAAAAAAAB///gAcAAAAAAAAAAB//////////v///////////wAAAAAAAAAAAAAAAAAAAD//+AAcgAAAAAAAAAD//////////3///////////gAAAAAAAAAAAAAAAAAAAA7/+AAdwAAAAAAAAAH///////+//9///////////AAAAAAAAAAAAAAAAAAAAAf/+AANgAAAAAAAAAH///////+//8f//////////QAAAAAAAAAAAAAAAAAAAAc/+AABgAAAAAAAAAP///////+f//4Af///////+wAAAAAAAAAAAAAAAAAAAAGf+AAcgAAAAAAAAAf////////P//+Af///////8wAAAAAAAAAAAAIAAAAAAAGf+AB/gAAAAAAAAAf////////n///AH///////wwAAAAAAAAAAAAPAAAAAAAAP+A9H4AAAAAAAAA/////////3///AD///v//8AgAAAAAAAAAAAABgAAAAAAAP+B8B8AAAAAAAAA/////////n//+AD//8P/+YAAAAAAAAAAAAAABwAAAAAAAP/B4A/4AAAAAAAAf////////z//8AA//wH/88AAAAAAAAAAAAAAAgAAAAAAAD//4B3/gAAAAAAAf////////x//8AAf/AD/+4A4AAAAAAAAAAAAAAAAAAAAAB//wAwjgAAAAAAAf////////5//4AAf/AD/+AA4AAAAAAAAAAAAAAAAAAAAAAP/0AAAAAAAAAAAf////////4//gAAf+AD//gB4AAAAAAAAAAAAAAAAAAAAAADP/gAAAAAAAAAAf////////8/+AAAf4ADf/gBwAAAAAAAAAAAAAAAAAAAAAAAH/gAAAAAAAAAA///////////wAAAP4AAf/gA4AAAAAAAAAAAAAAAAAAAAAAAD/gAAAAAAAAAAf//////////gAAAP4AAP/wA8AAAAAAAAAAAAAAAAAAAAAAAAPgAoAAAAAAAAf/////////8MAAAPwAAP/wAzAAAAAAAAAAAAAAAAAAAAAAAAHgH8AAAAAAAAf/////////x8AAAHwAAMfwBfAAAAAAAAAAAAAAAAAAAAAAAADgP//AAAAAAAH//////////8AAADwAAMfADfAAAAAAAAAAAAAAAAAAAAAAAAD/f//AAAAAAAH//////////4AAAD4AAMOAGNgAAAAAAAAAAAAAAAAAAAAAAAA////gAAAAAAD//////////4AAAD8AAOEAEPgAAAAAAAAAAAAAAAAAAAAAAAAN///wAAAAAAB//////////wAAABcAAOAAAfgAAAAAAAAAAAAAAAAAAAAAAAAA///6AAAAAAA//////////wAAAAcAAHgAMPgAAAAAAAAAAAAAAAAAAAAAAAAA////wAAAAAAP/x///////gAAAAIABzgAfBAAAAAAAAAAAAAAAAAAAAAAAAAA////4AAAAAAPuB///////AAAAAAAB7wA+AAAAAAAAAAAAAAAAAAAAAAAAAAA////4AAAAAAAAAP/////+AAAAAAAA/wD8AAAAAAAAAAAAAAAAAAAAAAAAAAB////4AAAAAAAAAH/////+AAAAAAAAfwX+AQAAAAAAAAAAAAAAAAAAAAAAAAB////+AAAAAAAAAH/////4AAAAAAAAP4f8xYAAAAAAAAAAAAAAAAAAAAAAAAH////8AAAAAAAAAH/////wAAAAAAAAHw//+YAAAAAAAAAAAAAAAAAAAAAAAAH/////wAAAAAAAAP/////gAAAAAAAADwf98bwAAAAAAAAAAAAAAAAAAAAAAAH/////8AAAAAAAAP/////AAAAAAAAAD4f58D5gAAAAAAAAAAAAAAAAAAAAAAH//////4AAAAAAAH////+AAAAAAAAAD8P7wN78AwAAAAAAAAAAAAAAAAAAAAH//////8AAAAAAAB////+AAAAAAAAAA+H55+//gcAAAAAAAAAAAAAAAAAAAAP//////+AAAAAAAB////8AAAAAAAAAA8Ap8A3/wcAAAAAAAAAAAAAAAAAAAAH///////gAAAAAAB////4AAAAAAAAAAfABsAJ/zzAAAAAAAAAAAAAAAAAAAAP///////wAAAAAAA////8AAAAAAAAAAH+AAAI//hgAAAAAAAAAAAAAAAAAAAD///////wAAAAAAA////8AAAAAAAAAAD/gAAA/8A4AAAAAAAAAAAAAAAAAAAD///////gAAAAAAA////8AAAAAAAAAAAP37wB/OAGAAAAAAAAAAAAAAAAAAAB///////gAAAAAAA////8AAAAAAAAAAAAPnAAGHgHAAAAAAAAAAAAAAAAAAAB///////AAAAAAAAf///+AAAAAAAAAAAAAmAACHgBgAAAAAAAAAAAAAAAAAAA//////+AAAAAAAAf///+AAAAAAAAAAAAAAB+HAAAAAAAAAAAAAAAAAAAAAAA//////+AAAAAAAAf///+AwAAAAAAAAAAAAD+HAAAAAAAAAAAAAAAAAAAAAAAf/////8AAAAAAAA////+B4AAAAAAAAAAAA3+HAAAAAAAAAAAAAAAAAAAAAAAf/////8AAAAAAAA////+B4AAAAAAAAAAAB/8HwAADAAAAAAAAAAAAAAAAAAAP/////8AAAAAAAB////+H4AAAAAAAAAAAD//HwAADAAgAAAAAAAAAAAAAAAAD/////4AAAAAAAB////+P4AAAAAAAAAAAH//nwAABADAAAAAAAAAAAAAAAAAA/////4AAAAAAAB////4fwAAAAAAAAAAAP///4AAAAGAAAAAAAAAAAAAAAAAAf////4AAAAAAAB////gPwAAAAAAAAAAAf///4AAAAGAAAAAAAAAAAAAAAAAAf////4AAAAAAAA////APwAAAAAAAAAAB////+AAAAAAAAAAAAAAAAAAAAAAAf////wAAAAAAAAf//+AfgAAAAAAAAAAP////+AAMAAAAAAAAAAAAAAAAAAAAf////wAAAAAAAAf///AfAAAAAAAAAAA//////AAOAAAAAAAAAAAAAAAAAAAAf////gAAAAAAAAP///AfAAAAAAAAAAB//////gADAAAAAAAAAAAAAAAAAAAAf///8AAAAAAAAAP///AfAAAAAAAAAAB//////gAAAAAAAAAAAAAAAAAAAAAAf///wAAAAAAAAAP///AfAAAAAAAAAAB//////4AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAP//8AOAAAAAAAAAAB//////4AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAP//4AAAAAAAAAAAAB//////8AAAAAAAAAAAAAAAAAAAAAAf///AAAAAAAAAAH//4AAAAAAAAAAAAA//////8AAAAAAAAAAAAAAAAAAAAAA////AAAAAAAAAAD//4AAAAAAAAAAAAA//////8AAAAAAAAAAAAAAAAAAAAAA///+AAAAAAAAAAB//wAAAAAAAAAAAAAf/////8AAAAAAAAAAAAAAAAAAAAAA///8AAAAAAAAAAB//gAAAAAAAAAAAAA//////8AAAAAAAAAAAAAAAAAAAAAA///4AAAAAAAAAAA//gAAAAAAAAAAAAAf/////4AAAAAAAAAAAAAAAAAAAAAA///wAAAAAAAAAAB/+AAAAAAAAAAAAAAf/w///4AAAAAAAAAAAAAAAAAAAAAA///wAAAAAAAAAAA/8AAAAAAAAAAAAAAf+AP//wAAAAAAAAAAAAAAAAAAAAAA///gAAAAAAAAAAA8AAAAAAAAAAAAAAAfIAH//wAADAAAAAAAAAAAAAAAAAAB//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAD//gAABgAAAAAAAAAAAAAAAAAB//8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/gAABwAAAAAAAAAAAAAAAAAD//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/AAAA+AAAAAAAAAAAAAAAAAD//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8AAAA+AAAAAAAAAAAAAAAAAD/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAAB8AAAAAAAAAAAAAAAAAD/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA2AAADYAAAAAAAAAAAAAAAAAH/sAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAH4AAAAAAAAAAAAAAAAAH/4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAAHAAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAA/AAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAAAAAAAAAAAAAAAAH/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4AAAAAAAAAAAAAAAAAAP+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwAAAAAAAAAAAAAAAAAAP/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/gAAAAAAAAAAAAAAAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP+AAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8D4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH8BgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAAAAAAAAAAAAAAAAB4AAAAAAA4BAAAEAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAAAAAAAAAAAAAAAAP8AAAAGAD//8f///wAAAAAAAAAAAAAAAAAAAAAAADwAAAAAAAAAAAAAAAAAH//34AP//////////4AAAAAAAAAAAAAAAAAAAAAAAT4AAAAAAAAAAAAAAAGD////8A/////////////AAAAAAAAAAAAAAAAAAAAAA/8AAAAAAAAAAAQRwA//////8f/////////////8AAAAAAAAAAAAAAAAAAAAA/+AAAAAAAABAH//////////8f///////////////gAAAAAAAAAAAAAB9AAAP/+AAAAAAAA/////////////5////////////////8AAAAAAAAAAAAAD/AgAH/+AAAAAAAH//////////////////////////////8AAAAAAAAAD3wgD///////AAAAAAAf//////////////////////////////wAAAAAAAB/////H//////+AAAAAAAf//////////////////////////////AAAAAAAH/////////////wAAAAAAP//////////////////////////////4AAAAAGAf////////////8AAAAAAf///////////////////////////////wAAAAAH/////////////+AAAAQAP////////////////////////////////4AAAAD3/////////////8AAAD+A/////////////////////////////////+AAAAB4/////////////wADAP+A/////////////////////////////////wAAAAAAAP////////////h/h/+Af///////////////////////////////+AAAAAAB///////////////5AH9//////////////////////////////////AAAAAAAP////////////////////////////////////////////////////8AAACAAP/////////////////////////////////////////////////////wA//8AB///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////'.replace(/\s+/g,''),LW=360,LH=180,land=null;
try{var bin=atob(B64);if(bin.length===LW*LH/8){land=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)land[i]=bin.charCodeAt(i);}}catch(e){}
function isLand(lat,lon){if(!land)return Math.random()<.32;var x=Math.floor((lon+180)/360*LW);x=((x%LW)+LW)%LW;
  var y=Math.max(0,Math.min(LH-1,Math.floor((90-lat)/180*LH)));return (land[y*45+(x>>3)]>>(7-(x&7)))&1;}
var BASE=null;
function basePoints(){if(BASE)return BASE;var n=11000,ga=Math.PI*(3-Math.sqrt(5)),o=[];
  for(var i=0;i<n;i++){var y=1-(i/(n-1))*2,r=Math.sqrt(1-y*y),t=ga*i,x=Math.cos(t)*r,z=Math.sin(t)*r;
    if(isLand(Math.asin(y)*57.29578,Math.atan2(x,z)*57.29578))o.push(x,y,z);}
  BASE=new Float32Array(o);return BASE;}
var THEMES={
  d1:{dot:'17,38,84',hi:'#FFFFFF',lo:'#EAF0F8',edge:'rgba(188,142,47,.6)',glow:'188,142,47',grid:'17,38,84',orbit:['188,142,47','28,58,122'],el:['#C99A3A','#1C3A7A'],arc:'188,142,47'},
  d2:{dot:'24,63,140',hi:'#FFFFFF',lo:'#D9E8FF',edge:'rgba(45,96,185,.38)',glow:'110,175,255',grid:'45,96,185',orbit:['214,162,58','45,96,185'],el:['#D6A23A','#2FA4F0'],arc:'214,162,58'},
  d3:{dot:'13,27,51',hi:'#FFFFFF',lo:'#ECF0F6',edge:'rgba(13,27,51,.22)',glow:'153,5,5',grid:'13,27,51',orbit:['153,5,5','13,27,51'],el:['#990505','#22314F'],arc:'153,5,5'}};
var ORBITS=[{k:1.3,ax:1.2,az:-.42,sp:.62,w:1.9},{k:1.44,ax:1.28,az:.5,sp:-.46,w:1.4}];

function Globe(host){
  var cv=host.querySelector('canvas'),ctx=cv.getContext('2d'),T=THEMES[host.getAttribute('data-globe')]||THEMES.d2;
  var P=basePoints();
  if(host.clientWidth<340){var sub=[];for(var q=0;q<P.length;q+=6)sub.push(P[q],P[q+1],P[q+2]);P=new Float32Array(sub);}
  var N=P.length/3,S=new Float32Array(P.length),DL=new Float32Array(N),SX=new Float32Array(N),SY=new Float32Array(N),BK=new Int8Array(N);
  for(var i=0;i<N;i++){var j=i*3,f=1.7+Math.random()*1.8;S[j]=P[j]*f+(Math.random()-.5)*.7;S[j+1]=P[j+1]*f+(Math.random()-.5)*.7;S[j+2]=P[j+2]*f+(Math.random()-.5)*.7;
    DL[i]=(1-P[j+1])*.32+Math.random()*.38;}
  var w=0,h=0,cx=0,cy=0,R=0,th=Math.PI/2+.32,ph=.38,PH0=.38,vth=0,AUTO=.15,drag=false,lx=0,ly=0,form=-1,last=0,run=false,raf=0,arcs=[],nextArc=0,tmp=[0,0,0];
  function size(){var dpr=Math.min(2,W.devicePixelRatio||1);w=host.clientWidth;h=host.clientHeight;cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);cx=w/2;cy=h/2;R=Math.min(w,h)*.335;}
  function rot(x,y,z,o){var cT=Math.cos(th),sT=Math.sin(th),cP=Math.cos(ph),sP=Math.sin(ph),x1=x*cT+z*sT,z1=-x*sT+z*cT;o[0]=x1;o[1]=y*cP-z1*sP;o[2]=y*sP+z1*cP;}
  function vis(x,y,z){return z>0||((x-cx)*(x-cx)+(y-cy)*(y-cy)>R*R*1.0004);}
  function orbitPt(O,t,time,o){var x=Math.cos(t)*O.k,y=Math.sin(t)*O.k,c=Math.cos(O.ax),s=Math.sin(O.ax),z=y*s;y=y*c;
    c=Math.cos(O.az);s=Math.sin(O.az);var x2=x*c-y*s,y2=x*s+y*c,pa=time*.06*O.sp;c=Math.cos(pa);s=Math.sin(pa);o[0]=x2*c+z*s;o[1]=y2;o[2]=-x2*s+z*c;}
  function drawOrbits(time,front,fade){
    for(var q=0;q<ORBITS.length;q++){var O=ORBITS[q],col=T.orbit[q%T.orbit.length],seg=200,open=false,px=0,py=0,pz=0;
      ctx.lineWidth=O.w;ctx.lineCap='round';ctx.strokeStyle='rgba('+col+','+((front?.92:.32)*fade).toFixed(3)+')';
      for(var k=0;k<=seg;k++){orbitPt(O,k/seg*TAU,time,tmp);var x=cx+tmp[0]*R,y=cy-tmp[1]*R,z=tmp[2];
        if(k>0){var on=((z+pz)/2>=0)===front;if(on){if(!open){ctx.beginPath();ctx.moveTo(px,py);open=true;}ctx.lineTo(x,y);}else if(open){ctx.stroke();open=false;}}
        px=x;py=y;pz=z;}
      if(open)ctx.stroke();
      var te=time*O.sp*1.15+q*2.2;orbitPt(O,te,time,tmp);
      if((tmp[2]>=0)===front){var ex=cx+tmp[0]*R,ey=cy-tmp[1]*R,ec=T.el[q%T.el.length],a=fade*(front?1:.5);
        for(var m=16;m>=1;m--){orbitPt(O,te-m*.032*(O.sp>0?1:-1),time,tmp);if((tmp[2]>=0)!==front)continue;
          ctx.globalAlpha=a*(1-m/17)*.55;ctx.fillStyle=ec;ctx.beginPath();ctx.arc(cx+tmp[0]*R,cy-tmp[1]*R,3.4*(1-m/19),0,TAU);ctx.fill();}
        var g=ctx.createRadialGradient(ex,ey,0,ex,ey,16);g.addColorStop(0,ec);g.addColorStop(1,'rgba(255,255,255,0)');
        ctx.globalAlpha=a*.55;ctx.fillStyle=g;ctx.beginPath();ctx.arc(ex,ey,16,0,TAU);ctx.fill();
        ctx.globalAlpha=a;ctx.fillStyle=ec;ctx.beginPath();ctx.arc(ex,ey,4.6,0,TAU);ctx.fill();
        ctx.fillStyle='rgba(255,255,255,.85)';ctx.beginPath();ctx.arc(ex-1.4,ey-1.4,1.5,0,TAU);ctx.fill();ctx.globalAlpha=1;}}}
  function drawBody(fade){
    var g=ctx.createRadialGradient(cx,cy,R*.92,cx,cy,R*1.34);g.addColorStop(0,'rgba('+T.glow+','+(.26*fade).toFixed(3)+')');g.addColorStop(1,'rgba('+T.glow+',0)');
    ctx.fillStyle=g;ctx.beginPath();ctx.arc(cx,cy,R*1.34,0,TAU);ctx.fill();
    var b=ctx.createRadialGradient(cx-R*.38,cy-R*.42,R*.06,cx,cy,R*1.02);b.addColorStop(0,T.hi);b.addColorStop(1,T.lo);
    ctx.globalAlpha=fade;ctx.fillStyle=b;ctx.beginPath();ctx.arc(cx,cy,R,0,TAU);ctx.fill();ctx.strokeStyle=T.edge;ctx.lineWidth=1.2;ctx.stroke();ctx.globalAlpha=1;}
  function drawGrid(fade){ctx.strokeStyle='rgba('+T.grid+','+(.09*fade).toFixed(3)+')';ctx.lineWidth=.8;ctx.beginPath();
    var L,s,open,lat,lon;
    for(L=0;L<6;L++){lon=L*Math.PI/6;open=false;for(s=0;s<=60;s++){lat=-Math.PI/2+s/60*Math.PI;rot(Math.cos(lat)*Math.sin(lon),Math.sin(lat),Math.cos(lat)*Math.cos(lon),tmp);
      if(tmp[2]>0){var x=cx+tmp[0]*R,y=cy-tmp[1]*R;if(!open){ctx.moveTo(x,y);open=true;}else ctx.lineTo(x,y);}else open=false;}}
    for(L=-2;L<=2;L++){lat=L*Math.PI/6;open=false;for(s=0;s<=90;s++){lon=s/90*TAU;rot(Math.cos(lat)*Math.sin(lon),Math.sin(lat),Math.cos(lat)*Math.cos(lon),tmp);
      if(tmp[2]>0){var x2=cx+tmp[0]*R,y2=cy-tmp[1]*R;if(!open){ctx.moveTo(x2,y2);open=true;}else ctx.lineTo(x2,y2);}else open=false;}}
    ctx.stroke();}
  function project(fe){var cT=Math.cos(th),sT=Math.sin(th),cP=Math.cos(ph),sP=Math.sin(ph),forming=fe<2.5;
    for(var i=0,j=0;i<N;i++,j+=3){var x=P[j],y=P[j+1],z=P[j+2];
      if(forming){var e=Math.max(0,Math.min(1,(fe-DL[i])/1.2));e=1-Math.pow(1-e,3);if(e<1){x=S[j]+(x-S[j])*e;y=S[j+1]+(y-S[j+1])*e;z=S[j+2]+(z-S[j+2])*e;}}
      var x1=x*cT+z*sT,z1=-x*sT+z*cT,y2=y*cP-z1*sP,z2=y*sP+z1*cP,sx=cx+x1*R,sy=cy-y2*R;SX[i]=sx;SY[i]=sy;
      if(!vis(sx,sy,z2)){BK[i]=-1;continue;}var rr=Math.sqrt(x*x+y*y+z*z)||1,zz=z2/rr;BK[i]=zz<.2?0:zz<.5?1:zz<.78?2:3;}}
  function drawDots(){var sz=[.9,1.15,1.4,1.7],al=[.34,.6,.84,1],sc=Math.max(1,Math.min(1.5,R/150));
    for(var b=0;b<4;b++){ctx.fillStyle='rgba('+T.dot+','+al[b]+')';ctx.beginPath();var r=sz[b]*sc;
      for(var i=0;i<N;i++){if(BK[i]!==b)continue;ctx.moveTo(SX[i]+r,SY[i]);ctx.arc(SX[i],SY[i],r,0,TAU);}ctx.fill();}}
  function spawnArc(time){var a,b,dp,n=0;do{var ia=(Math.random()*N|0)*3,ib=(Math.random()*N|0)*3;a=[P[ia],P[ia+1],P[ia+2]];b=[P[ib],P[ib+1],P[ib+2]];
      dp=a[0]*b[0]+a[1]*b[1]+a[2]*b[2];n++;}while((dp>.86||dp<-.15)&&n<24);
    arcs.push({a:a,b:b,om:Math.acos(Math.max(-1,Math.min(1,dp))),t0:time,dur:2.3+Math.random()*1.1});}
  function arcPt(A,s,o){var so=Math.sin(A.om)||1e-6,k1=Math.sin((1-s)*A.om)/so,k2=Math.sin(s*A.om)/so,lift=1+(.1+.3*A.om/Math.PI)*Math.sin(Math.PI*s);
    rot((A.a[0]*k1+A.b[0]*k2)*lift,(A.a[1]*k1+A.b[1]*k2)*lift,(A.a[2]*k1+A.b[2]*k2)*lift,o);}
  function drawArcs(time){ctx.lineWidth=1.7;ctx.lineCap='round';
    for(var q=arcs.length-1;q>=0;q--){var A=arcs[q],p=(time-A.t0)/A.dur;if(p>1.5){arcs.splice(q,1);continue;}
      var s1=Math.min(1,p),s0=Math.max(0,p-.42),open=false,fadeA=p>1?Math.max(0,1-(p-1)*2):1;
      ctx.strokeStyle='rgba('+T.arc+','+(.95*fadeA).toFixed(3)+')';
      for(var k=0;k<=30;k++){arcPt(A,s0+(s1-s0)*k/30,tmp);var x=cx+tmp[0]*R,y=cy-tmp[1]*R;
        if(vis(x,y,tmp[2])){if(!open){ctx.beginPath();ctx.moveTo(x,y);open=true;}else ctx.lineTo(x,y);}else if(open){ctx.stroke();open=false;}}
      if(open)ctx.stroke();
      if(p<1){arcPt(A,s1,tmp);var hx=cx+tmp[0]*R,hy=cy-tmp[1]*R;if(vis(hx,hy,tmp[2])){var g=ctx.createRadialGradient(hx,hy,0,hx,hy,9);
          g.addColorStop(0,'rgba('+T.arc+',1)');g.addColorStop(1,'rgba('+T.arc+',0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(hx,hy,9,0,TAU);ctx.fill();}}
      else{rot(A.b[0],A.b[1],A.b[2],tmp);if(tmp[2]>0){var rp=(p-1)/.5;ctx.strokeStyle='rgba('+T.arc+','+(1-rp).toFixed(3)+')';ctx.lineWidth=1.3;
          ctx.beginPath();ctx.arc(cx+tmp[0]*R,cy-tmp[1]*R,2+rp*13,0,TAU);ctx.stroke();ctx.lineWidth=1.7;}}}}
  function render(time,fe){var fade=Math.max(0,Math.min(1,(fe-.45)/.9));
    ctx.clearRect(0,0,w,h);drawOrbits(time,false,fade);drawBody(fade);drawGrid(fade);project(fe);drawDots();drawArcs(time);drawOrbits(time,true,fade);}
  function frame(now){var time=now/1000,dt=last?Math.min(.05,time-last):0;last=time;if(form<0)form=time;
    if(!drag){th+=vth+AUTO*dt;vth*=.94;ph+=(PH0-ph)*.03;}
    var fe=time-form;if(fe>1.8&&time>nextArc&&arcs.length<5){spawnArc(time);nextArc=time+.55+Math.random()*.6;}
    render(time,fe);if(run)raf=requestAnimationFrame(frame);}
  function still(){render(4,99);}
  size();
  if(reduce){still();}
  else if('IntersectionObserver' in W){new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&!run){run=true;last=0;raf=requestAnimationFrame(frame);}
      else if(!e.isIntersecting&&run){run=false;cancelAnimationFrame(raf);}});},{threshold:.15}).observe(host);}
  else{run=true;raf=requestAnimationFrame(frame);}
  cv.addEventListener('pointerdown',function(e){drag=true;lx=e.clientX;ly=e.clientY;vth=0;try{cv.setPointerCapture(e.pointerId);}catch(x){}});
  cv.addEventListener('pointermove',function(e){if(!drag)return;var dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;
    th+=dx*.0065;vth=dx*.0065;ph=Math.max(-.9,Math.min(.9,ph+dy*.004));if(reduce)still();});
  ['pointerup','pointercancel','lostpointercapture'].forEach(function(ev){cv.addEventListener(ev,function(){drag=false;});});
  var rt;W.addEventListener('resize',function(){clearTimeout(rt);rt=setTimeout(function(){size();if(!run)still();},150);});
}
[].forEach.call(d.querySelectorAll('[data-globe]'),Globe);
})();

