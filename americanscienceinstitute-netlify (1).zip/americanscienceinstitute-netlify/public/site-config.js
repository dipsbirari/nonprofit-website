/* Public settings for static hosting (Netlify). Secret keys go in Netlify → Site configuration → Environment variables. */
window.ASI_CONFIG = {
  recaptchaSiteKey: '',   // Google reCAPTCHA v3 site key (public)
  ga4Id: ''               // Google Analytics 4 measurement ID, e.g. G-XXXXXXXXXX
};
